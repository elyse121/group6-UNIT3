import os
import csv
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

OUT_DIR = os.path.dirname(os.path.abspath(__file__))

# =====================================================================
# 1. PARAMETERS
# =====================================================================
SEED = 7
DT = 0.2                          # seconds per measurement sample
SPEED = 25.0                      # m/s (90 km/h)
CELL_X = {"A": 0.0, "B": 1000.0, "C": 2000.0}     # base-station positions along the road (m)
N_SAMPLES = 410                   # device runs from x = 50 m to about 2095 m
P_REF_DBM = -10.0                 # RSRP at 1 m
PATH_LOSS_EXP = 3.5
SHADOW_SIGMA = 2.5                # dB, slowly varying shadowing (AR(1))
SHADOW_RHO = 0.9
MEAS_SIGMA = 1.5                  # dB, independent measurement noise
RLF_DBM = -110.0                  # serving RSRP below this counts as out-of-sync
RLF_COUNT = 5                     # consecutive out-of-sync samples before RLF is declared
ATTACH_MIN_DBM = -115.0           # weakest cell the device will camp on
IDLE_WAIT = 3                     # samples spent searching for a cell while IDLE
HO_TICKS = 2                      # samples taken by the handover execution
PINGPONG_WINDOW = 10              # samples (2 s): handing back within this window is a ping-pong
C_LIGHT = 3.0e8
TS = 1.0 / 30.72e6                # LTE basic time unit; timing-advance step = 16 * Ts


# =====================================================================
# 2. SCRIPTED THREE-CELL SCENARIO
# =====================================================================
def build_scenario():
    rng = np.random.default_rng(SEED)
    pos = 50.0 + SPEED * DT * np.arange(N_SAMPLES)
    sig = {}
    for cell, x in CELL_X.items():
        dist = np.maximum(np.abs(pos - x), 20.0)
        mean = P_REF_DBM - 10 * PATH_LOSS_EXP * np.log10(dist)
        shadow = np.zeros(N_SAMPLES)
        for k in range(1, N_SAMPLES):
            shadow[k] = SHADOW_RHO * shadow[k - 1] + np.sqrt(1 - SHADOW_RHO ** 2) * SHADOW_SIGMA * rng.normal()
        sig[cell] = mean + shadow + rng.normal(0, MEAS_SIGMA, N_SAMPLES)
    return pos, sig


# =====================================================================
# 3. HANDOVER POLICIES (identical interface: reset() and decide(serving, rsrp))
# =====================================================================
class NaivePolicy:
    name = "Naive"

    def reset(self):
        pass

    def decide(self, serving, rsrp):
        best = max((c for c in rsrp if c != serving), key=lambda c: rsrp[c])
        if rsrp[best] > rsrp[serving]:
            return best, f"{best} stronger than {serving} by {rsrp[best] - rsrp[serving]:.1f} dB (no margin, no timer)"
        return None, ""


class HysteresisTTTPolicy:
    def __init__(self, margin_db, ttt):
        self.margin, self.ttt = margin_db, ttt
        self.name = f"Hysteresis {margin_db:g} dB + TTT {ttt}"
        self.reset()

    def reset(self):
        self.candidate, self.streak = None, 0

    def decide(self, serving, rsrp):
        best = max((c for c in rsrp if c != serving), key=lambda c: rsrp[c])
        if rsrp[best] > rsrp[serving] + self.margin:
            self.streak = self.streak + 1 if best == self.candidate else 1
            self.candidate = best
            if self.streak >= self.ttt:
                return best, (f"{best} exceeded {serving} by more than {self.margin:g} dB "
                              f"for {self.streak} consecutive samples")
        else:
            self.reset()
        return None, ""


# =====================================================================
# 4. THE STATE MACHINE
# =====================================================================
def timing_advance(distance_m):
    """LTE-style timing-advance index: round-trip delay in units of 16*Ts (about 0.52 microseconds)."""
    return int(round((2 * distance_m / C_LIGHT) / (16 * TS)))


def simulate(policy, pos, sig):
    cells = list(sig)
    state, serving, ho_target = "IDLE", None, None
    idle_wait, ho_left, rlf_streak = IDLE_WAIT, 0, 0
    log, handovers, rlfs, rach_count, idle_samples = [], [], 0, 0, 0
    policy.reset()

    def record(t, frm, to, cell, trigger):
        log.append({"t": t, "from": frm, "to": to, "cell": cell, "trigger": trigger})

    for k in range(N_SAMPLES):
        ts = k * DT
        r = {c: sig[c][k] for c in cells}

        if state == "IDLE":
            idle_samples += 1
            if idle_wait > 0:
                idle_wait -= 1
                continue
            best = max(cells, key=lambda c: r[c])
            if r[best] < ATTACH_MIN_DBM:
                continue
            # ---- Random access: the four logical RACH steps ----
            dist = abs(pos[k] - CELL_X[best])
            ta = timing_advance(dist)
            record(ts, "IDLE", "RACH", best, f"cell selection: strongest cell {best} ({r[best]:.1f} dBm)")
            record(ts, "RACH", "RACH", best, "step 1/4  Msg1 random-access preamble sent")
            record(ts + 0.004, "RACH", "RACH", best, f"step 2/4  Msg2 random-access response, timing advance = {ta}")
            record(ts + 0.010, "RACH", "RACH", best, "step 3/4  Msg3 RRC connection request sent")
            record(ts + 0.020, "RACH", "CONNECTED", best, "step 4/4  Msg4 contention resolved")
            rach_count += 1
            state, serving, rlf_streak = "CONNECTED", best, 0
            policy.reset()

        elif state in ("CONNECTED", "HANDOVER"):
            # radio-link monitoring applies in both states
            rlf_streak = rlf_streak + 1 if r[serving] < RLF_DBM else 0
            if rlf_streak >= RLF_COUNT:
                record(ts, state, "IDLE", serving,
                       f"RLF: {serving} below {RLF_DBM:.0f} dBm for {RLF_COUNT} samples ({r[serving]:.1f} dBm)")
                rlfs += 1
                state, serving, idle_wait, rlf_streak = "IDLE", None, IDLE_WAIT, 0
                policy.reset()
                continue

            if state == "CONNECTED":
                target, why = policy.decide(serving, r)
                if target:
                    record(ts, "CONNECTED", "HANDOVER", serving, f"{why}; target {target}")
                    state, ho_target, ho_left = "HANDOVER", target, HO_TICKS
            else:
                ho_left -= 1
                if ho_left == 0:
                    if r[ho_target] < RLF_DBM:
                        record(ts, "HANDOVER", "IDLE", ho_target,
                               f"handover failure: target {ho_target} at {r[ho_target]:.1f} dBm")
                        rlfs += 1
                        state, serving, idle_wait, rlf_streak = "IDLE", None, IDLE_WAIT, 0
                    else:
                        record(ts, "HANDOVER", "CONNECTED", ho_target, f"handover complete {serving}->{ho_target}")
                        handovers.append((k, serving, ho_target))
                        serving, rlf_streak = ho_target, 0
                        state = "CONNECTED"
                    policy.reset()

    # serving-cell timeline for plotting
    timeline = []
    cur = None
    entries = sorted(log, key=lambda e: e["t"])
    idx = 0
    for k in range(N_SAMPLES):
        while idx < len(entries) and entries[idx]["t"] <= k * DT + 1e-9:
            e = entries[idx]
            if e["to"] == "CONNECTED":
                cur = e["cell"]
            elif e["to"] == "IDLE":
                cur = None
            idx += 1
        timeline.append(cur)

    pingpong = 0
    for a, b in zip(handovers, handovers[1:]):
        if b[2] == a[1] and (b[0] - a[0]) <= PINGPONG_WINDOW:
            pingpong += 1

    return {"policy": policy.name, "log": log, "handovers": handovers, "rlfs": rlfs,
            "pingpong": pingpong, "rach": rach_count, "idle_s": idle_samples * DT, "timeline": timeline}


def format_log(result):
    lines = []
    for e in result["log"]:
        lines.append(f"t={e['t']:7.3f} s | {e['from']:<9} -> {e['to']:<9} | cell {e['cell']} | {e['trigger']}")
    return lines


# =====================================================================
# 5. RUN
# =====================================================================
pos, sig = build_scenario()

with open(os.path.join(OUT_DIR, "three_cell_signals.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["sample", "time_s", "position_m", "rsrp_A_dBm", "rsrp_B_dBm", "rsrp_C_dBm"])
    for k in range(N_SAMPLES):
        w.writerow([k, f"{k * DT:.1f}", f"{pos[k]:.0f}", f"{sig['A'][k]:.2f}", f"{sig['B'][k]:.2f}", f"{sig['C'][k]:.2f}"])

policies = [NaivePolicy(), HysteresisTTTPolicy(3, 5), HysteresisTTTPolicy(10, 20)]
results = [simulate(p, pos, sig) for p in policies]

print("=" * 88)
print(f"SCENARIO: device from {pos[0]:.0f} m to {pos[-1]:.0f} m at {SPEED:.0f} m/s, cells at {list(CELL_X.values())} m, "
      f"{N_SAMPLES} samples of {DT} s")
print("=" * 88)
print(f"{'Policy':<30}{'Handovers':>10}{'RLFs':>6}{'Ping-pong':>11}{'RACH runs':>11}{'Idle (s)':>10}")
for res in results:
    print(f"{res['policy']:<30}{len(res['handovers']):>10}{res['rlfs']:>6}{res['pingpong']:>11}"
          f"{res['rach']:>11}{res['idle_s']:>10.1f}")

for res in results:
    fname = "transition_log_" + res["policy"].lower().replace(" ", "_").replace("+", "plus") + ".txt"
    lines = format_log(res)
    with open(os.path.join(OUT_DIR, fname), "w") as f:
        f.write(f"Policy: {res['policy']}\n" + "\n".join(lines) + "\n")
    print("\n" + "-" * 88)
    print(f"{res['policy']}: {len(lines)} transitions logged ({fname}); first 12:")
    print("-" * 88)
    for line in lines[:12]:
        print(line)

# =====================================================================
# 6. FIGURES
# =====================================================================
colors = {"A": "tab:blue", "B": "tab:orange", "C": "tab:green"}

fig, ax = plt.subplots(figsize=(11, 4.6))
for c in "ABC":
    ax.plot(pos, sig[c], color=colors[c], linewidth=0.9, label=f"Cell {c} (at {CELL_X[c]:.0f} m)")
ax.axhline(RLF_DBM, color="red", linestyle=":", linewidth=1, label=f"RLF threshold {RLF_DBM:.0f} dBm")
ax.set_xlabel("Device position along the road (m)")
ax.set_ylabel("RSRP (dBm)")
ax.set_title("Scripted three-cell scenario: RSRP of cells A, B and C as the device moves A → B → C")
ax.grid(alpha=0.3)
ax.legend(ncol=4, fontsize=8.5, loc="lower center")
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "three_cell_scenario.png"), dpi=130)

level = {"A": 3, "B": 2, "C": 1, None: 0}
fig, axes = plt.subplots(3, 1, figsize=(11, 8.2), sharex=True, sharey=True)
for ax, res in zip(axes, results):
    y = [level[c] for c in res["timeline"]]
    ax.step(pos, y, where="post", color="black", linewidth=1.4)
    for (k, a, b) in res["handovers"]:
        ax.plot(pos[k], level[b], marker="^", color="tab:purple", markersize=7)
    for e in res["log"]:
        if e["to"] == "IDLE":
            kk = min(int(round(e["t"] / DT)), N_SAMPLES - 1)
            ax.plot(pos[kk], 0, marker="X", color="red", markersize=10)
    ax.set_yticks([0, 1, 2, 3])
    ax.set_yticklabels(["Idle", "Cell C", "Cell B", "Cell A"])
    ax.set_title(f"{res['policy']}: {len(res['handovers'])} handovers, {res['rlfs']} RLF, "
                 f"{res['pingpong']} ping-pong", fontsize=10.5)
    ax.grid(alpha=0.3)
axes[-1].set_xlabel("Device position along the road (m)")
fig.suptitle("Serving cell over time under each policy (▲ = handover completed, red ✖ = radio link failure)", fontsize=11)
fig.tight_layout(rect=(0, 0, 1, 0.97))
fig.savefig(os.path.join(OUT_DIR, "policy_timelines.png"), dpi=130)


def draw_state_machine():
    fig, ax = plt.subplots(figsize=(12, 7.2))
    ax.set_xlim(0, 13)
    ax.set_ylim(-1.6, 7.4)
    ax.axis("off")

    def box(x: float, y: float, w: float, h: float, text: str, fc: str, fs: float = 10.0, bold: bool = True):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05,rounding_size=0.15",
                                    facecolor=fc, edgecolor="black", linewidth=1.3))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs,
                fontweight="bold" if bold else "normal")

    def arrow(p1, p2, text=None, tpos=None, rad: float = 0.0, color: str = "black"):
        ax.annotate("", xy=p2, xytext=p1,
                    arrowprops=dict(arrowstyle="-|>", lw=1.6, color=color, connectionstyle=f"arc3,rad={rad}"))
        if text:
            tx, ty = tpos if tpos else ((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2 + 0.25)
            ax.text(tx, ty, text, ha="center", va="bottom", fontsize=8.8, color=color)

    box(0.4, 2.9, 2.2, 1.4, "IDLE\n(no connection)", "#E8E8E8")
    # RACH super-state with four sub-steps
    ax.add_patch(FancyBboxPatch((4.0, 1.0), 3.7, 5.0, boxstyle="round,pad=0.05,rounding_size=0.2",
                                facecolor="#FFF2CC", edgecolor="black", linewidth=1.3))
    ax.text(5.85, 5.65, "RANDOM ACCESS (RACH)", ha="center", va="center", fontsize=10.5, fontweight="bold")
    steps = ["1  Msg1: preamble", "2  Msg2: RAR + timing advance", "3  Msg3: RRC connection request",
             "4  Msg4: contention resolution"]
    ys = [4.55, 3.5, 2.45, 1.4]
    for s, y in zip(steps, ys):
        box(4.25, y, 3.2, 0.7, s, "white", fs=8.8, bold=False)
    for a, b in zip(ys[:-1], ys[1:]):
        arrow((5.85, a), (5.85, b + 0.7))
    box(9.2, 2.9, 3.0, 1.4, "CONNECTED\n(active link to serving cell)", "#D9EAD3", fs=9.5)
    box(9.2, 0.0, 3.0, 1.2, "HANDOVER\nIN PROGRESS", "#CFE2F3", fs=9.5)

    arrow((2.6, 3.6), (4.0, 3.6), "cell selected", (3.3, 3.85))
    arrow((7.7, 3.6), (9.2, 3.6), "contention\nresolved", (8.45, 3.7))
    arrow((10.2, 2.9), (10.2, 1.2), "policy trigger", (9.0, 1.95))
    arrow((11.2, 1.2), (11.2, 2.9), "handover\ncomplete", (12.2, 1.9))
    # RLF paths back to IDLE
    ax.plot([10.7, 10.7, 1.5, 1.5], [4.3, 6.9, 6.9, 4.4], color="red", lw=1.6)
    ax.annotate("", xy=(1.5, 4.3), xytext=(1.5, 4.9), arrowprops=dict(arrowstyle="-|>", lw=1.6, color="red"))
    ax.text(6.1, 6.95, "Radio Link Failure: serving RSRP below threshold for 5 samples (too-late handover)",
            ha="center", va="bottom", fontsize=8.8, color="red")
    ax.plot([10.7, 10.7], [0.0, -0.9], color="red", lw=1.6)
    ax.plot([10.7, 1.5, 1.5], [-0.9, -0.9, 2.9], color="red", lw=1.6)
    ax.annotate("", xy=(1.5, 2.9), xytext=(1.5, 2.3), arrowprops=dict(arrowstyle="-|>", lw=1.6, color="red"))
    ax.text(6.1, -1.45, "Radio Link Failure or handover failure (target below threshold) while in HANDOVER",
            ha="center", va="bottom", fontsize=8.8, color="red")
    ax.set_title("Connection and handover state machine", fontsize=13, fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "state_machine.png"), dpi=130)


draw_state_machine()
plt.show()