import os
import math
import numpy as np
import matplotlib.pyplot as plt

OUT_DIR = os.path.dirname(os.path.abspath(__file__))

# =====================================================================
# 1. CONFIGURATION (all inputs in one place)
# =====================================================================
TOTAL_SPECTRUM_MHZ = 25.0          # total spectrum allocation (one direction)
CHANNEL_BW_KHZ = 200.0             # bandwidth of one channel
AREA_KM2 = 1000.0                  # coverage area
R_KM = 2.0                         # cell radius (centre to corner of the hexagon)
N_LIST = [1, 3, 4, 7, 9, 12]       # candidate reuse factors (valid hexagonal cluster sizes)
PATH_LOSS_EXP = 4.0                # path-loss exponent used in the SIR illustration
SPLIT_N = 4                        # reuse factor used for the cell-splitting scenario
SPLIT_FACTORS = [2, 4]             # radius divided by 2 and by 4


def total_channels():
    return int(TOTAL_SPECTRUM_MHZ * 1000 // CHANNEL_BW_KHZ)


def hex_area(radius_km):
    """Area of a regular hexagon with circumradius R: (3*sqrt(3)/2) * R^2."""
    return 1.5 * math.sqrt(3) * radius_km ** 2


def n_cells(radius_km, area_km2=AREA_KM2):
    """Approximate number of cells that fit the area (rounded down to whole cells)."""
    return int(area_km2 // hex_area(radius_km))


def capacity(n, radius_km):
    """Return (channels per cell, number of cells, total capacity in channels)."""
    cpc = total_channels() // n
    cells = n_cells(radius_km)
    return cpc, cells, cpc * cells


def q_ratio(n):
    return math.sqrt(3 * n)


def sir_db(n, interferers, exponent=PATH_LOSS_EXP):
    """First-tier SIR approximation: (D/R)^n / i0, in dB."""
    return 10 * math.log10(q_ratio(n) ** exponent / interferers)


# =====================================================================
# 2. CAPACITY PER REUSE FACTOR
# =====================================================================
print("=" * 86)
print("CONFIGURATION")
print("=" * 86)
print(f"Total spectrum        : {TOTAL_SPECTRUM_MHZ} MHz  ->  {total_channels()} channels of {CHANNEL_BW_KHZ:.0f} kHz")
print(f"Coverage area         : {AREA_KM2:.0f} km^2")
print(f"Cell radius R         : {R_KM} km  ->  hexagon area {hex_area(R_KM):.3f} km^2  ->  {n_cells(R_KM)} cells")
print(f"Path-loss exponent    : {PATH_LOSS_EXP} (SIR illustration only)")

rows = []
print("\n" + "=" * 86)
print("CAPACITY, Q AND SIR FOR EACH REUSE FACTOR (omnidirectional cells, R = 2 km)")
print("=" * 86)
print(f"{'N':>3}{'Channels/cell':>15}{'Cells':>8}{'Capacity':>10}{'Q=sqrt(3N)':>12}{'Omni SIR (dB)':>15}")
for n in N_LIST:
    cpc, cells, cap = capacity(n, R_KM)
    rows.append((n, cpc, cells, cap, q_ratio(n), sir_db(n, 6)))
    print(f"{n:>3}{cpc:>15}{cells:>8}{cap:>10}{q_ratio(n):>12.3f}{sir_db(n, 6):>15.2f}")

# =====================================================================
# 3. CELL SPLITTING
# =====================================================================
print("\n" + "=" * 86)
print(f"CELL SPLITTING (N = {SPLIT_N})")
print("=" * 86)
base_cpc, base_cells, base_cap = capacity(SPLIT_N, R_KM)
split_rows = [("Original", R_KM, base_cpc, base_cells, base_cap, 1.0, 0.0)]
print(f"{'Scenario':<22}{'R (km)':>8}{'Cells':>8}{'Capacity':>10}{'Gain':>8}{'Tx power change':>18}")
print(f"{'Original':<22}{R_KM:>8.2f}{base_cells:>8}{base_cap:>10}{1.0:>8.2f}{'-':>18}")
for f in SPLIT_FACTORS:
    r_new = R_KM / f
    cpc, cells, cap = capacity(SPLIT_N, r_new)
    power_db = -10 * PATH_LOSS_EXP * math.log10(f)       # keep the same received power at the new edge
    split_rows.append((f"R / {f}", r_new, cpc, cells, cap, cap / base_cap, power_db))
    print(f"{'Radius divided by ' + str(f):<22}{r_new:>8.2f}{cells:>8}{cap:>10}{cap / base_cap:>8.2f}{power_db:>15.1f} dB")
print(f"(ideal gain for R/2 = 4x and for R/4 = 16x; integer rounding of the cell count explains the small differences)")

# =====================================================================
# 4. SECTORING (120 degrees): FIRST-TIER INTERFERERS 6 -> 2
# =====================================================================
print("\n" + "=" * 86)
print("SECTORING ILLUSTRATION (first-tier interferers: omni = 6, 120-degree sectors = 2)")
print("=" * 86)
print(f"{'Configuration':<28}{'N':>3}{'Interferers':>13}{'SIR (dB)':>10}{'Channels per site':>19}")
sector_rows = []
for n in (3, 4, 7):
    for label, i0 in (("Omnidirectional", 6), ("120-degree sectors", 2)):
        cps = total_channels() // n
        sector_rows.append((label, n, i0, sir_db(n, i0), cps))
        print(f"{label:<28}{n:>3}{i0:>13}{sir_db(n, i0):>10.2f}{cps:>19}")
omni7 = sir_db(7, 6)
sect4 = sir_db(4, 2)
gain = (total_channels() // 4) / (total_channels() // 7)
print(f"\nOmni N=7 SIR = {omni7:.2f} dB;  120-degree N=4 SIR = {sect4:.2f} dB  (difference {sect4 - omni7:+.2f} dB)")
print(f"Moving from omni N=7 to sectored N=4 at about the same SIR raises channels per site by {gain:.2f}x "
      f"(ideal 7/4 = {7 / 4:.2f}x)")

# =====================================================================
# 5. ILLUSTRATIVE DEPLOYMENTS (for the written analysis)
# =====================================================================
print("\n" + "=" * 86)
print("ILLUSTRATIVE DEPLOYMENTS (same 1000 km^2 area and spectrum)")
print("=" * 86)
deploy = [("Dense urban", 0.5, 4), ("Suburban", 2.0, 7), ("Rural", 10.0, 7)]
print(f"{'Deployment':<14}{'R (km)':>8}{'N':>3}{'Cells':>8}{'Ch/cell':>9}{'Capacity':>10}{'Channels per km^2':>19}")
deploy_rows = []
for name, r, n in deploy:
    cpc, cells, cap = capacity(n, r)
    deploy_rows.append((name, r, n, cells, cpc, cap, cap / AREA_KM2))
    print(f"{name:<14}{r:>8.1f}{n:>3}{cells:>8}{cpc:>9}{cap:>10}{cap / AREA_KM2:>19.2f}")

# =====================================================================
# 6. CHARTS
# =====================================================================
ns = [r[0] for r in rows]
caps = [r[3] for r in rows]
qs = [r[4] for r in rows]

fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.8))
bars = a1.bar([str(n) for n in ns], caps, color="tab:blue")
for b, c in zip(bars, caps):
    a1.text(b.get_x() + b.get_width() / 2, c, f"{c:,}", ha="center", va="bottom", fontsize=9)
a1.set_xlabel("Reuse factor N")
a1.set_ylabel("Total system capacity (channels)")
a1.set_title("Capacity versus reuse factor")
a1.grid(axis="y", alpha=0.3)

a2.plot(qs, caps, "o-", color="tab:red")
for n, q, c in zip(ns, qs, caps):
    a2.annotate(f"N={n}", (q, c), textcoords="offset points", xytext=(7, 6), fontsize=9)
a2.set_xlabel("Co-channel reuse ratio Q = D/R")
a2.set_ylabel("Total system capacity (channels)")
a2.set_title("Capacity versus Q (larger Q = less interference)")
a2.grid(alpha=0.3)
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "capacity_vs_N_and_Q.png"), dpi=140)

fig, (b1, b2) = plt.subplots(1, 2, figsize=(12.5, 5))
labels = ["Omni N=7\n(R = 2 km)", "Omni N=4\n(R = 2 km)", "N=4, 120° sectors\n(R = 2 km)",
          "N=4, split\nR/2", "N=4, split\nR/4"]
# capacity of the sectored N=4 plan equals the omni N=4 channel count per site (same cells), so it
# differs from omni N=4 only in SIR; show it next to omni N=7, which has the same SIR.
values = [capacity(7, R_KM)[2], capacity(4, R_KM)[2], capacity(4, R_KM)[2],
          capacity(4, R_KM / 2)[2], capacity(4, R_KM / 4)[2]]
colors = ["tab:gray", "tab:blue", "tab:green", "tab:orange", "tab:red"]
bars = b1.bar(range(len(values)), values, color=colors)
b1.set_yscale("log")
for i, v in enumerate(values):
    b1.text(i, v, f"{v:,}", ha="center", va="bottom", fontsize=9)
b1.set_xticks(range(len(values)))
b1.set_xticklabels(labels, fontsize=8.5)
b1.set_ylabel("Total system capacity (channels, log scale)")
b1.set_title("Capacity levers: reuse factor, sectoring, cell splitting")
b1.grid(axis="y", alpha=0.3, which="both")

ns_s = [3, 4, 7, 9, 12]
b2.plot(ns_s, [sir_db(n, 6) for n in ns_s], "o-", label="Omnidirectional (6 interferers)", color="tab:blue")
b2.plot(ns_s, [sir_db(n, 2) for n in ns_s], "s-", label="120° sectors (2 interferers)", color="tab:green")
b2.axhline(18, color="gray", linestyle=":", label="18 dB illustrative target")
b2.set_xlabel("Reuse factor N")
b2.set_ylabel("Approximate SIR (dB)")
b2.set_title(f"First-tier SIR estimate (path-loss exponent {PATH_LOSS_EXP:.0f})")
b2.grid(alpha=0.3)
b2.legend(fontsize=9)
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "capacity_levers_and_sir.png"), dpi=140)

plt.show()
