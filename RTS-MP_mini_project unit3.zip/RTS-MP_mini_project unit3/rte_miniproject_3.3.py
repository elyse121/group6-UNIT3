import argparse
import csv
import heapq
import os
import statistics
import threading
import time
from dataclasses import dataclass, field, replace
from typing import List

SLICE_MS = 0.5          # granularity at which the CPU worker can be preempted


@dataclass
class Source:
    name: str
    priority: int       # smaller number = higher priority
    period_ms: float
    top_ms: float       # top-half (ISR) duration
    bottom_ms: float    # bottom-half (task) duration


@dataclass
class Config:
    name: str
    sources: List[Source]
    duration_s: float = 10.0
    note: str = ""


def baseline_sources():
    return [Source("S1 (high)", 0, 20.0, 0.5, 2.0),
            Source("S2 (medium)", 1, 30.0, 0.5, 4.0),
            Source("S3 (low)", 2, 50.0, 1.0, 8.0)]


def make_configs(duration):
    base = baseline_sources()
    cfgs = [Config("A: baseline (short top halves)", base, duration)]
    for top in (8.0, 15.0):
        long_s2 = [replace(s, top_ms=top) if s.name.startswith("S2") else s for s in base]
        tag = "B1" if top == 8.0 else "B2"
        cfgs.append(Config(f"{tag}: S2 long top half ({top:g} ms)", long_s2, duration, f"S2 top half 0.5 -> {top:g} ms"))
    for p in (40.0, 10.0, 6.0):
        srcs = [replace(s, period_ms=p) if s.name.startswith("S1") else s for s in base]
        cfgs.append(Config(f"C: S1 period {p:g} ms", srcs, duration, "sweep of highest-priority period"))
    return cfgs


class Simulator:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.heap, self.seq = [], 0
        self.cv = threading.Condition()            # protects heap, isr_active
        self.isr_lock = threading.Lock()           # serialises top halves (no nesting)
        self.isr_active = 0
        self.stop = threading.Event()
        self.records = []                          # one dict per occurrence
        self.segments = []                         # (kind, source, start_ms, end_ms) for the timeline
        self.preemptions = {s.name: 0 for s in cfg.sources}
        self.t0 = 0.0
        self.rec_lock = threading.Lock()

    def now_ms(self):
        return (time.perf_counter() - self.t0) * 1000

    # ---------------------------------------------------------------- interrupt source (top half)
    def source_thread(self, src: Source):
        k = 0
        while not self.stop.is_set():
            k += 1
            assert_ms = k * src.period_ms                           # scheduled assertion instant
            delay = (self.t0 + assert_ms / 1000) - time.perf_counter()
            if delay > 0:
                time.sleep(delay)
            if self.stop.is_set() or assert_ms > self.cfg.duration_s * 1000:
                return
            with self.isr_lock:                                     # wait here = interrupt latency
                start = self.now_ms()
                with self.cv:
                    self.isr_active += 1                            # CPU is now taken at interrupt level
                time.sleep(src.top_ms / 1000)                       # top-half work
                end = self.now_ms()
                with self.cv:
                    self.isr_active -= 1
                    self.seq += 1
                    task = {"src": src, "assert": assert_ms, "int_lat": start - assert_ms, "top": end - start,
                            "remaining": src.bottom_ms, "n": k}
                    heapq.heappush(self.heap, (src.priority, self.seq, task))   # defer work to bottom half
                    self.cv.notify_all()
            with self.rec_lock:
                self.segments.append(("TH", src.name, start, end))

    # ---------------------------------------------------------------- the single simulated CPU
    def cpu_worker(self):
        while True:
            with self.cv:
                while not self.heap and not self.stop.is_set():
                    self.cv.wait(0.05)
                if not self.heap:
                    return
                prio, _, task = heapq.heappop(self.heap)
            src = task["src"]
            seg_start = None
            preempted = False
            while task["remaining"] > 1e-9:
                with self.cv:
                    if self.isr_active:                              # a top half preempts us mid-task
                        if seg_start is not None:
                            self.segments.append(("BH", src.name, seg_start, self.now_ms()))
                            seg_start = None
                        if not preempted:
                            self.preemptions[src.name] += 1
                            preempted = True
                        while self.isr_active:
                            self.cv.wait(0.001)
                    if self.heap and self.heap[0][0] < prio:         # higher-priority bottom half ready
                        if seg_start is not None:
                            self.segments.append(("BH", src.name, seg_start, self.now_ms()))
                        self.seq += 1
                        heapq.heappush(self.heap, (prio, self.seq, task))    # re-queue the remainder
                        self.preemptions[src.name] += 1
                        break
                if seg_start is None:
                    seg_start = self.now_ms()
                chunk = min(SLICE_MS, task["remaining"])
                time.sleep(chunk / 1000)
                task["remaining"] -= chunk
            else:
                end = self.now_ms()
                if seg_start is not None:
                    self.segments.append(("BH", src.name, seg_start, end))
                with self.rec_lock:
                    self.records.append({"source": src.name, "n": task["n"], "assert_ms": task["assert"],
                                         "interrupt_latency_ms": task["int_lat"], "top_half_ms": task["top"],
                                         "response_latency_ms": end - task["assert"]})

    def run(self):
        self.t0 = time.perf_counter()
        cpu = threading.Thread(target=self.cpu_worker, daemon=True)
        ths = [threading.Thread(target=self.source_thread, args=(s,), daemon=True) for s in self.cfg.sources]
        cpu.start()
        for t in ths:
            t.start()
        time.sleep(self.cfg.duration_s + 0.3)
        self.stop.set()
        with self.cv:
            self.cv.notify_all()
        for t in ths:
            t.join(timeout=1)
        cpu.join(timeout=2)
        return self


def p95(vals):
    s = sorted(vals)
    return s[max(0, int(round(0.95 * len(s))) - 1)]


def summarize(sim: Simulator):
    rows = []
    for src in sim.cfg.sources:
        rs = [r for r in sim.records if r["source"] == src.name]
        resp = [r["response_latency_ms"] for r in rs]
        il = [r["interrupt_latency_ms"] for r in rs]
        th = [r["top_half_ms"] for r in rs]
        rows.append({"config": sim.cfg.name, "source": src.name, "n": len(rs),
                     "min": min(resp), "mean": statistics.mean(resp), "max": max(resp), "p95": p95(resp),
                     "int_lat_mean": statistics.mean(il), "int_lat_max": max(il),
                     "top_mean": statistics.mean(th), "preempted": sim.preemptions[src.name]})
    return rows


def print_table(rows):
    print(f"{'Source':<13}{'n':>5}{'min':>8}{'mean':>8}{'max':>9}{'p95':>8}{'IntLat mean':>13}{'IntLat max':>12}"
          f"{'TH mean':>9}{'Preempted':>11}")
    for r in rows:
        print(f"{r['source']:<13}{r['n']:>5}{r['min']:>8.2f}{r['mean']:>8.2f}{r['max']:>9.2f}{r['p95']:>8.2f}"
              f"{r['int_lat_mean']:>13.2f}{r['int_lat_max']:>12.2f}{r['top_mean']:>9.2f}{r['preempted']:>11}")


def aggregate(rows_per_run):
    """Median across repeated runs of every statistic (robust to a one-off host scheduling stall)."""
    out = []
    for i, first in enumerate(rows_per_run[0]):
        row = dict(first)
        for k in ("min", "mean", "max", "p95", "int_lat_mean", "int_lat_max", "top_mean", "preempted"):
            row[k] = statistics.median(rr[i][k] for rr in rows_per_run)
        row["n"] = first["n"]
        out.append(row)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--duration", type=float, default=8.0, help="seconds per run")
    ap.add_argument("--repeats", type=int, default=3, help="runs per configuration (median reported)")
    a = ap.parse_args()
    here = os.path.dirname(os.path.abspath(__file__))
    all_rows, sims = [], []
    for i, cfg in enumerate(make_configs(a.duration)):
        print("=" * 100)
        print(f"CONFIG {cfg.name}   ({a.repeats} runs x {cfg.duration_s:g} s)  periods(ms)=" +
              ", ".join(f"{s.name.split()[0]}:{s.period_ms:g}" for s in cfg.sources) + "  top halves(ms)=" +
              ", ".join(f"{s.name.split()[0]}:{s.top_ms:g}" for s in cfg.sources) + "  bottom halves(ms)=" +
              ", ".join(f"{s.name.split()[0]}:{s.bottom_ms:g}" for s in cfg.sources))
        print("=" * 100)
        runs = [Simulator(cfg).run() for _ in range(a.repeats)]
        per_run = [summarize(r) for r in runs]
        rows = aggregate(per_run)
        print("(each statistic = median of the per-run values over the repeats; n = occurrences per run)")
        print_table(rows)
        all_rows += rows
        sims.append(runs[0])
        with open(os.path.join(here, f"interrupt_log_{i + 1}.csv"), "w", newline="") as f:
            fields = ["run"] + list(runs[0].records[0].keys())
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for ri, r in enumerate(runs, 1):
                for rec in sorted(r.records, key=lambda x: x["assert_ms"]):
                    w.writerow({"run": ri, **rec})
    with open(os.path.join(here, "interrupt_summary.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(all_rows[0].keys()))
        w.writeheader()
        w.writerows(all_rows)
    plots(sims, all_rows, here)


def plots(sims, rows, here):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not installed - plots skipped")
        return
    col = {"S1 (high)": "#1F3864", "S2 (medium)": "#2E8B57", "S3 (low)": "#E69F00"}
    lanes = {"S1 (high)": 3, "S2 (medium)": 2, "S3 (low)": 1}
    fig, axes = plt.subplots(2, 1, figsize=(11, 6.2), sharex=True)
    for ax, sim, title in zip(axes, sims[:2], ("A: baseline (short top halves)", "B1: S2 top half = 8 ms")):
        w0, w1 = 2000.0, 2200.0
        for kind, src, s, e in sim.segments:
            if e < w0 or s > w1:
                continue
            y = lanes[src]
            if kind == "TH":
                ax.barh(0, e - s, left=s, height=0.7, color=col[src], edgecolor="black", hatch="///")
                ax.annotate(src.split()[0], (s, 0.45), fontsize=7, ha="left", va="bottom")
            else:
                ax.barh(y, e - s, left=s, height=0.7, color=col[src], edgecolor="black", linewidth=0.4)
        ax.set_yticks([0, 1, 2, 3])
        ax.set_yticklabels(["Top halves\n(interrupt level)", "S3 bottom half", "S2 bottom half", "S1 bottom half"],
                           fontsize=8)
        ax.set_title(title, fontsize=10)
        ax.grid(axis="x", alpha=0.3)
        ax.set_xlim(w0, w1)
    axes[-1].set_xlabel("Time since start (ms)  -  200 ms window; hatched = top half (always preempts); gaps inside a "
                        "bottom-half lane = preemption")
    fig.suptitle("Preemption timeline: top halves preempt bottom halves, higher-priority bottom halves preempt lower",
                 fontsize=10.5)
    fig.tight_layout()
    fig.savefig(os.path.join(here, "interrupt_timeline.png"), dpi=150)

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11.5, 4.6))
    cfgs = []
    for r in rows:
        if r["config"] not in cfgs:
            cfgs.append(r["config"])
    srcs = ["S1 (high)", "S2 (medium)", "S3 (low)"]
    width = 0.26
    for j, s in enumerate(srcs):
        vals = [next(r["max"] for r in rows if r["config"] == c and r["source"] == s) for c in cfgs[:3]]
        a1.bar([x + (j - 1) * width for x in range(3)], vals, width, label=s, color=col[s])
    a1.set_yscale("log")
    a1.set_xticks(range(3))
    a1.set_xticklabels(["A: baseline", "B1: S2 top\nhalf 8 ms", "B2: S2 top\nhalf 15 ms"], fontsize=8.5)
    a1.set_ylabel("Worst-case response latency (ms, log scale)")
    a1.set_title("Effect of one long top half")
    a1.legend(fontsize=8)
    a1.grid(axis="y", alpha=0.3)
    sweep = [cfgs[0]] + cfgs[3:]
    periods = []
    for c in sweep:
        periods.append(next(s.period_ms for sim in sims if sim.cfg.name == c for s in sim.cfg.sources
                            if s.name.startswith("S1")))
    order = sorted(range(len(sweep)), key=lambda i: -periods[i])
    for s in srcs:
        a2.plot([periods[i] for i in order],
                [next(r["max"] for r in rows if r["config"] == sweep[i] and r["source"] == s) for i in order],
                "o-", label=s, color=col[s])
    a2.invert_xaxis()
    a2.set_xlabel("S1 period (ms)  -  arrival rate rises to the right")
    a2.set_ylabel("Worst-case response latency (ms)")
    a2.set_title("Arrival-rate sweep of the highest-priority source")
    a2.legend(fontsize=8)
    a2.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(here, "interrupt_latency_summary.png"), dpi=150)


if __name__ == "__main__":
    main()