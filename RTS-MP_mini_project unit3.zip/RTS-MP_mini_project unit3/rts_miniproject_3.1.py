import queue
import random
import statistics
import sys
import threading
import time


# =====================================================================
# PARTS 1 and 2: race condition and its fix
# =====================================================================
shared_counter = 0                      # shared state at module scope
counter_lock = threading.Lock()         # used only by the fixed version


def increment_unsafe(iterations):
    global shared_counter
    for _ in range(iterations):
        local = shared_counter          # 1. read
        time.sleep(0.0001)              # 2. widen the interleaving window (forces a task switch)
        shared_counter = local + 1      # 3. write back a stale value -> lost update


def increment_safe(iterations):
    global shared_counter
    for _ in range(iterations):
        with counter_lock:              # only one task may be inside at a time
            local = shared_counter
            time.sleep(0.0001)          # same delay as before, but now harmless
            shared_counter = local + 1


def run_counter(target, n_threads=5, iterations=1000, label=""):
    global shared_counter
    shared_counter = 0
    threads = [threading.Thread(target=target, args=(iterations,)) for _ in range(n_threads)]
    t0 = time.perf_counter()
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    expected = n_threads * iterations
    lost = expected - shared_counter
    print(f"{label:<11} threads={n_threads:<3} expected={expected:<6} final={shared_counter:<6} "
          f"lost={lost:<6} ({100 * lost / expected:5.1f}% lost)  time={time.perf_counter() - t0:.2f}s")


def part_race():
    print("=" * 90 + "\nPARTS 1-2: race_demo (no lock) vs race_fixed (with Lock) - three runs each\n" + "=" * 90)
    for _ in range(3):
        run_counter(increment_unsafe, label="race_demo")
    for _ in range(3):
        run_counter(increment_safe, label="race_fixed")


# =====================================================================
# PART 3: bounded message queue
# =====================================================================
def run_queue(maxsize=5, consumer_sleep=0.0, items=20, producer_gap=0.002):
    q = queue.Queue(maxsize=maxsize)
    latencies, blocked = [], []

    def producer_task():
        for i in range(items):
            stamp = time.perf_counter()                     # timestamp when the item is created
            q.put((i, stamp))                               # blocks automatically while the queue is full
            blocked.append(time.perf_counter() - stamp)     # time spent waiting for space
            time.sleep(producer_gap)

    def consumer_task():
        for _ in range(items):
            _, stamp = q.get()
            latencies.append(time.perf_counter() - stamp)   # send -> receipt latency
            if consumer_sleep:
                time.sleep(consumer_sleep)                  # slow consumer

    p, c = threading.Thread(target=producer_task), threading.Thread(target=consumer_task)
    p.start(); c.start(); p.join(); c.join()
    return latencies, blocked


def part_queue():
    print("\n" + "=" * 90 + "\nPART 3: queue_sim (queue.Queue(maxsize=5), 20 items)\n" + "=" * 90)
    for cs in (0.0, 0.010):
        lat, blk = run_queue(5, cs)
        n_blocked = sum(1 for b in blk if b > 0.001)
        print(f"maxsize=5 consumer_sleep={cs * 1000:4.1f} ms | latency ms: min={min(lat) * 1000:6.2f} "
              f"max={max(lat) * 1000:6.2f} avg={statistics.mean(lat) * 1000:6.2f} | producer blocked "
              f"{n_blocked:2d}/20 puts, total {sum(blk) * 1000:6.1f} ms")


# =====================================================================
# PART 4: counting semaphore pool
# =====================================================================
def run_pool(pool_size=3, tasks=8, seed=1, verbose=True):
    rnd = random.Random(seed)
    holds = [rnd.uniform(0.05, 0.15) for _ in range(tasks)]     # per-task hold time (s)
    pool_semaphore = threading.Semaphore(pool_size)
    guard = threading.Lock()
    state = {"holders": 0, "peak": 0}
    waits = {}

    def task(tid):
        t0 = time.perf_counter()
        pool_semaphore.acquire()                                # blocks when all blocks are in use
        waits[tid] = time.perf_counter() - t0
        with guard:
            state["holders"] += 1
            state["peak"] = max(state["peak"], state["holders"])
        time.sleep(holds[tid])                                  # use the resource
        with guard:
            state["holders"] -= 1
        pool_semaphore.release()

    ts = [threading.Thread(target=task, args=(i,)) for i in range(tasks)]
    for t in ts:
        t.start()
        time.sleep(0.001)                                       # tiny stagger so the order is stable
    for t in ts:
        t.join()
    w = list(waits.values())
    n_wait = sum(1 for x in w if x >= 0.005)
    if verbose:
        for tid in range(tasks):
            tag = "immediate" if waits[tid] < 0.005 else "waited"
            print(f"  task {tid}: hold={holds[tid] * 1000:6.1f} ms  wait={waits[tid] * 1000:7.2f} ms  ({tag})")
    print(f"Semaphore({pool_size}): peak holders={state['peak']}; {n_wait} of {tasks} tasks waited; "
          f"mean wait={statistics.mean(w) * 1000:.1f} ms, max wait={max(w) * 1000:.1f} ms")


def part_pool():
    print("\n" + "=" * 90 + "\nPART 4: semaphore_pool (Semaphore(3), eight tasks)\n" + "=" * 90)
    run_pool(3, verbose=True)


# =====================================================================
# PART 5: dispatch latency
# =====================================================================
def part_timing(n=200):
    print("\n" + "=" * 90 + "\nPART 5: timing_overhead (200 thread start -> Event.wait() return intervals)\n" + "=" * 90)
    samples = []
    for _ in range(n):
        ev = threading.Event()
        t = threading.Thread(target=ev.set)
        t0 = time.perf_counter()
        t.start()
        ev.wait()
        samples.append((time.perf_counter() - t0) * 1e6)        # microseconds
        t.join()
    s = sorted(samples)
    print(f"samples         : {n}")
    print(f"minimum         : {min(samples):9.1f} us")
    print(f"mean            : {statistics.mean(samples):9.1f} us")
    print(f"95th percentile : {s[int(round(0.95 * n)) - 1]:9.1f} us")
    print(f"maximum (worst-case observed dispatch latency): {max(samples):9.1f} us")
    print(f"max / mean      : {max(samples) / statistics.mean(samples):9.1f}x")


# =====================================================================
# LAB TASKS
# =====================================================================
def livelock(seconds=3):
    """Two tasks take two locks in opposite orders, try-acquire the second, back off and retry in lock-step
    (barriers keep them synchronized). Retry counters keep growing but neither ever gets both locks."""
    lock_a, lock_b = threading.Lock(), threading.Lock()
    barrier = threading.Barrier(2)
    retries = {"T1": 0, "T2": 0}
    completed = {"T1": False, "T2": False}
    stop = threading.Event()

    def worker(name, first, second):
        while True:
            first.acquire()                       # take the first lock
            barrier.wait()                        # both now hold one lock
            if second.acquire(blocking=False):    # always fails while the peer holds it
                completed[name] = True
                second.release()
            else:
                retries[name] += 1                # back off and count the retry
            barrier.wait()
            first.release()                       # release and retry together
            barrier.wait()
            if stop.is_set() or completed[name]:
                return

    t1 = threading.Thread(target=worker, args=("T1", lock_a, lock_b))
    t2 = threading.Thread(target=worker, args=("T2", lock_b, lock_a))
    t1.start(); t2.start()
    for sec in range(1, seconds + 1):
        time.sleep(1)
        print(f"  t={sec}s retries T1={retries['T1']:>7,} T2={retries['T2']:>7,}  completed T1={completed['T1']} "
              f"T2={completed['T2']}  alive={t1.is_alive()}/{t2.is_alive()}")
    stop.set()
    t1.join(); t2.join()


def part_lab():
    print("\n" + "=" * 90 + "\nLAB TASK 1: race_demo with 5 vs 10 threads\n" + "=" * 90)
    for n in (5, 10):
        for _ in range(3):
            run_counter(increment_unsafe, n_threads=n, label="race_demo")
    print("\n" + "=" * 90 + "\nLAB TASK 2: semaphore count 1, 3 and 6\n" + "=" * 90)
    for k in (1, 3, 6):
        run_pool(k, verbose=False)
    print("\n" + "=" * 90 + "\nLAB TASK 3: livelock demonstration (retry counters, 3 s)\n" + "=" * 90)
    livelock()
    print("\n" + "=" * 90 + "\nLAB TASK 4: queue maxsize sweep (consumer sleeps 10 ms)\n" + "=" * 90)
    print(f"{'maxsize':>8}{'avg latency (ms)':>20}{'max latency (ms)':>20}{'producer blocked (ms)':>24}")
    for m in (1, 2, 5, 10, 20):
        lat, blk = run_queue(m, 0.010)
        print(f"{m:>8}{statistics.mean(lat) * 1000:>20.2f}{max(lat) * 1000:>20.2f}{sum(blk) * 1000:>24.1f}")
    print("\nLAB TASK 5 (written answer) is in the report: a Semaphore has no owner, so priority-inheritance-style\n"
          "reasoning (boost the holder) needs a Lock/mutex, which Section 3.4 defines as ownership-aware.")


PARTS = {"race": part_race, "queue": part_queue, "pool": part_pool, "timing": part_timing, "lab": part_lab}

if __name__ == "__main__":
    wanted = sys.argv[1:] or list(PARTS)
    for w in wanted:
        PARTS[w]()