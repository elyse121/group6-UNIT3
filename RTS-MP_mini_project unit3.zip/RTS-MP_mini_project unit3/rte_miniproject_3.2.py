import argparse
import csv
import os
import random
import statistics
import threading
import time

WINDOW = 0.0005          # sleep between the two lock acquisitions: widens the interleaving window (as in 3.1)
POLL = 0.0005            # back-off when the buffer is full / empty


class TrackedLock:
    """threading.Lock plus bookkeeping of who holds it and who is waiting (for the lock-wait snapshot)."""

    def __init__(self, name):
        self.name, self._lock = name, threading.Lock()
        self.holder, self.waiters = None, []
        self._meta = threading.Lock()

    def acquire(self):
        me = threading.current_thread().name
        with self._meta:
            self.waiters.append(me)
        self._lock.acquire()
        with self._meta:
            self.waiters.remove(me)
            self.holder = me

    def release(self):
        with self._meta:
            self.holder = None
        self._lock.release()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *exc):
        self.release()


class System:
    def __init__(self, capacity, producers, consumers, items, flawed, seed=1, work_ms=1.0):
        self.capacity, self.n_prod, self.n_cons, self.total = capacity, producers, consumers, items
        self.flawed, self.work = flawed, work_ms / 1000
        self.buffer, self.buffer_lock = [], TrackedLock("buffer_lock")
        self.stats = {"produced": 0, "consumed": 0, "wait_total": 0.0}
        self.stats_lock = TrackedLock("stats_lock")
        self.rnd = random.Random(seed)
        self.prod_waits, self.cons_waits = [], []
        self.stop = threading.Event()
        self.deadlocked = False
        self.snapshot_text = ""

    # ---------------------------------------------------------------- producers
    def producer(self, quota):
        rnd = random.Random(threading.current_thread().name)
        for _ in range(quota):
            time.sleep(rnd.uniform(0, 2 * self.work))                 # time to produce an item
            t0 = time.perf_counter()
            while not self.stop.is_set():
                self.buffer_lock.acquire()                            # producers: buffer_lock FIRST ...
                if len(self.buffer) < self.capacity:
                    self.buffer.append(time.perf_counter())
                    time.sleep(WINDOW)                                # hold buffer_lock while asking for stats_lock
                    self.stats_lock.acquire()                         # ... then stats_lock (hold-and-wait)
                    wait = time.perf_counter() - t0
                    self.stats["produced"] += 1
                    self.stats["wait_total"] += wait
                    self.prod_waits.append(wait)
                    self.stats_lock.release()
                    self.buffer_lock.release()
                    break
                self.buffer_lock.release()                            # buffer full: give it up and retry
                time.sleep(POLL)

    # ---------------------------------------------------------------- consumers
    def consumer(self, quota):
        rnd = random.Random(threading.current_thread().name)
        for _ in range(quota):
            t0 = time.perf_counter()
            while not self.stop.is_set():
                if self.flawed:
                    self.stats_lock.acquire()                         # FLAWED: stats_lock FIRST ...
                    time.sleep(WINDOW)
                    self.buffer_lock.acquire()                        # ... then buffer_lock (opposite order)
                else:
                    self.buffer_lock.acquire()                        # FIXED: same global order as producers
                    time.sleep(WINDOW)
                    self.stats_lock.acquire()
                got = bool(self.buffer)
                if got:
                    self.buffer.pop(0)
                    wait = time.perf_counter() - t0
                    self.stats["consumed"] += 1
                    self.stats["wait_total"] += wait
                    self.cons_waits.append(wait)
                if self.flawed:
                    self.buffer_lock.release(); self.stats_lock.release()
                else:
                    self.stats_lock.release(); self.buffer_lock.release()
                if got:
                    break
                time.sleep(POLL)                                      # buffer empty: retry
            time.sleep(rnd.uniform(0, 2 * self.work))                 # time to process the item

    # ---------------------------------------------------------------- watchdog
    def watchdog(self, stall_seconds):
        last, last_change = (-1, -1), time.perf_counter()
        while not self.stop.is_set():
            time.sleep(0.1)
            cur = (self.stats["produced"], self.stats["consumed"])
            if cur != last:
                last, last_change = cur, time.perf_counter()
            elif time.perf_counter() - last_change >= stall_seconds:
                self.deadlocked = True
                self.report(cur, time.perf_counter() - last_change)
                self.stop.set()
                return
            if cur == (self.total, self.total):
                return

    def report(self, cur, stalled):
        lines = [f"[WATCHDOG] DEADLOCK DETECTED: produced={cur[0]} consumed={cur[1]} unchanged for {stalled:.1f} s",
                 "[WATCHDOG] Lock-wait snapshot:"]
        for lk in (self.buffer_lock, self.stats_lock):
            lines.append(f"    {lk.name:<12} held by {lk.holder or '-':<12} waiting: {lk.waiters or '-'}")
        waiting_on = {}
        for lk in (self.buffer_lock, self.stats_lock):
            for w in lk.waiters:
                waiting_on[w] = lk
        lines.append("[WATCHDOG] Wait-for relationships (thread -> lock it needs -> thread holding it):")
        for th, lk in sorted(waiting_on.items()):
            lines.append(f"    {th:<12} -> {lk.name:<12} -> {lk.holder}")
        self.snapshot_text = "\n".join(lines)
        print(self.snapshot_text)

    # ---------------------------------------------------------------- run
    def run(self, stall_seconds=2.0, quiet=False):
        pq = [self.total // self.n_prod + (1 if i < self.total % self.n_prod else 0) for i in range(self.n_prod)]
        cq = [self.total // self.n_cons + (1 if i < self.total % self.n_cons else 0) for i in range(self.n_cons)]
        threads = [threading.Thread(target=self.producer, args=(q,), name=f"Producer-{i + 1}", daemon=True)
                   for i, q in enumerate(pq)]
        threads += [threading.Thread(target=self.consumer, args=(q,), name=f"Consumer-{i + 1}", daemon=True)
                    for i, q in enumerate(cq)]
        wd = threading.Thread(target=self.watchdog, args=(stall_seconds,), name="Watchdog", daemon=True)
        t0 = time.perf_counter()
        wd.start()
        for t in threads:
            t.start()
        while not self.stop.is_set():
            if not any(t.is_alive() for t in threads):
                break
            time.sleep(0.02)
        elapsed = time.perf_counter() - t0
        self.stop.set()
        if not self.deadlocked:
            for t in threads:
                t.join(timeout=1)
        return elapsed


def one_run(capacity, producers, consumers, items, flawed, stall=2.0, quiet=False):
    s = System(capacity, producers, consumers, items, flawed)
    elapsed = s.run(stall)
    done = s.stats["consumed"]
    res = {
        "capacity": capacity, "deadlocked": s.deadlocked, "elapsed": elapsed,
        "produced": s.stats["produced"], "consumed": done,
        "throughput": done / elapsed if elapsed else 0.0,
        "prod_wait_ms": statistics.mean(s.prod_waits) * 1000 if s.prod_waits else 0.0,
        "cons_wait_ms": statistics.mean(s.cons_waits) * 1000 if s.cons_waits else 0.0,
    }
    return res, s


def sweep(args):
    caps, repeats, rows = [1, 2, 5, 10, 25, 50], 3, []
    print(f"FIXED version, {args.producers} producers, {args.consumers} consumers, {args.items} items, "
          f"mean of {repeats} runs per capacity")
    print(f"{'capacity':>9}{'throughput (items/s)':>23}{'avg producer wait (ms)':>25}{'avg consumer wait (ms)':>25}"
          f"{'run time (s)':>14}")
    for c in caps:
        rs = [one_run(c, args.producers, args.consumers, args.items, False)[0] for _ in range(repeats)]
        assert not any(r["deadlocked"] for r in rs), "watchdog fired in the fixed version!"
        row = {k: statistics.mean(r[k] for r in rs) for k in ("throughput", "prod_wait_ms", "cons_wait_ms", "elapsed")}
        row["capacity"] = c
        row["tp_min"] = min(r["throughput"] for r in rs)
        row["tp_max"] = max(r["throughput"] for r in rs)
        rows.append(row)
        print(f"{c:>9}{row['throughput']:>23.1f}{row['prod_wait_ms']:>25.2f}{row['cons_wait_ms']:>25.2f}"
              f"{row['elapsed']:>14.2f}")
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "capacity_sweep.csv")
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(8.5, 4.8))
        xs = [str(r["capacity"]) for r in rows]
        ax.bar(xs, [r["throughput"] for r in rows], color="#1F3864", label="Throughput (items/s)")
        ax.set_xlabel("Buffer capacity (items)"); ax.set_ylabel("Throughput (items/s)")
        ax2 = ax.twinx()
        ax2.plot(xs, [r["prod_wait_ms"] for r in rows], "o-", color="#C0504D", label="Producer wait (ms)")
        ax2.plot(xs, [r["cons_wait_ms"] for r in rows], "s-", color="#E69F00", label="Consumer wait (ms)")
        ax2.set_ylabel("Average blocking time per item (ms)")
        h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
        ax.legend(h1 + h2, l1 + l2, loc="center right", fontsize=9)
        ax.set_title("Corrected bounded buffer: throughput and blocking time vs capacity")
        fig.tight_layout()
        fig.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), "throughput_vs_capacity.png"), dpi=150)
    except ImportError:
        print("(matplotlib not installed - chart skipped, CSV written)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", nargs="?", default="all", choices=["all", "flawed", "fixed", "sweep"])
    ap.add_argument("--capacity", type=int, default=5)
    ap.add_argument("--producers", type=int, default=3)
    ap.add_argument("--consumers", type=int, default=3)
    ap.add_argument("--items", type=int, default=300)
    ap.add_argument("--stall", type=float, default=2.0, help="seconds without progress before the watchdog fires")
    a = ap.parse_args()
    modes = ["flawed", "fixed", "sweep"] if a.mode == "all" else [a.mode]
    for mode in modes:
        if mode == "sweep":
            sweep(a)
            continue
        flawed = mode == "flawed"
        print("=" * 90)
        print(f"Mode={mode.upper()}  capacity={a.capacity}  producers={a.producers}  consumers={a.consumers}  "
              f"items={a.items}")
        r, s = one_run(a.capacity, a.producers, a.consumers, a.items, flawed, a.stall)
        if r["deadlocked"]:
            print(f"Run ended by the watchdog after {r['elapsed']:.1f} s with only "
                  f"{r['produced']}/{a.items} produced and {r['consumed']}/{a.items} consumed.")
        else:
            print(f"Completed: produced={r['produced']} consumed={r['consumed']} in {r['elapsed']:.2f} s "
                  f"({r['throughput']:.1f} items/s); watchdog did not trigger.")
            print(f"Average producer wait {r['prod_wait_ms']:.2f} ms, consumer wait {r['cons_wait_ms']:.2f} ms")